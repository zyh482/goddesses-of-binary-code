import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWebEngineWidgets import *
from basic_operations import *
from matrix_operations import *
from matplotlib import pyplot as plt
import numpy as np
import csv
import requests
import json
from random import randint, seed
from time import time
import re
import urllib
from sympy import symbols, Matrix, solve, diff, eye


class StackedWin(QWidget):

    def __init__(self):
        super(StackedWin, self).__init__()
        self.setFixedSize(1000, 600)
        self.setWindowFlags(Qt.FramelessWindowHint)

        self.setWindowOpacity(0.95)  # 设置窗口透明度
        self.setStyleSheet("QWidget{background-color: rgb(255,255,255)}")
                                     
        # 标题，最小化，最大化，关闭
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(20)
        sizePolicy.setVerticalStretch(20)
        spacerItem1 = QtWidgets.QSpacerItem(5, 20, QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Minimum)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(30)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        
        self.pushButton = QtWidgets.QPushButton()
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(20)
        sizePolicy.setVerticalStretch(20)
        sizePolicy.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy)
        self.pushButton.setMaximumSize(QtCore.QSize(20, 20))
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(lambda:self.on_pushButton_clicked())
        spacerItem4 = QtWidgets.QSpacerItem(8, 20, QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Minimum)
        self.pushButton_3 = QtWidgets.QPushButton()
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(20)
        sizePolicy.setVerticalStretch(20)
        sizePolicy.setHeightForWidth(self.pushButton_3.sizePolicy().hasHeightForWidth())
        self.pushButton_3.setSizePolicy(sizePolicy)
        self.pushButton_3.setMaximumSize(QtCore.QSize(20, 20))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(lambda:self.on_pushButton_3_clicked())
        spacerItem5 = QtWidgets.QSpacerItem(5, 20, QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Minimum)
        self._close_max_min_icon()
        
        # 定义列表
        self.label_title = QLabel('☪NALA')
        #站位弹簧
        spacerItem8 = QtWidgets.QSpacerItem(10, 10, QtWidgets.QSizePolicy.Minimum,
                                                QtWidgets.QSizePolicy.Maximum)
        spacerItem6 = QtWidgets.QSpacerItem(10, 10, QtWidgets.QSizePolicy.Minimum,
                                                QtWidgets.QSizePolicy.Maximum)
        spacerItem7 = QtWidgets.QSpacerItem(10, 10, QtWidgets.QSizePolicy.Maximum,
                                                QtWidgets.QSizePolicy.Maximum)
        spacerItem9 = QtWidgets.QSpacerItem(10, 10, QtWidgets.QSizePolicy.Maximum,
                                                QtWidgets.QSizePolicy.Maximum)
          
        self.list1 = QListWidget()
        self.list2 = QListWidget()
        self.label_1 = QLabel('计算助手')
        self.label_2 = QLabel('娱乐模式')
        list1_str = ['基础运算','矩阵运算','图像绘制']
        list2_str = ['时间与天气', '答案之书', '游戏：24点', '游戏：打地鼠']
        for i in range(3):
            self.item = QListWidgetItem(list1_str[i], self.list1)
            self.item.setTextAlignment(Qt.AlignCenter)  
            self.item.setSizeHint(QSize(15,40))
        for i in range(4):
            self.item = QListWidgetItem(list2_str[i], self.list2)
            self.item.setTextAlignment(Qt.AlignCenter)  
            self.item.setSizeHint(QSize(15, 40))
            
        # 美化list
        with open('QliststackQSS.qss', 'r') as f:   #导入QListWidget的qss样式
            self.list_style = f.read()
            
        self.list1.setStyleSheet(self.list_style)
        self.list1.setFrameShape(QListWidget.NoFrame)
        self.list1.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  #隐藏滚动条
        self.list1.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list2.setStyleSheet(self.list_style)
        self.list2.setFrameShape(QListWidget.NoFrame)
        self.list2.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  #隐藏滚动条
        self.list2.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)   
        
        self.font_title = QFont()
        self.font_title.setFamily("Microsoft YaHei") #设置字体
        self.font_title.setPointSize(12) #字体大小
        font_NALA = QFont()
        font_NALA.setFamily("UD Digi Kyokasho NK-B") 
        font_NALA.setPointSize(15)
        font_NALA.setBold(75)

        self.label_1.setFont(self.font_title)
        self.label_2.setFont(self.font_title)
        self.label_title.setFont(font_NALA)
        self.label_title.setStyleSheet("color: rgb(15, 89, 164)")
        self.label_1.setAlignment(Qt.AlignCenter)#居中
        self.label_2.setAlignment(Qt.AlignCenter)#居中
        self.label_title.setAlignment(Qt.AlignCenter)
        
        # 定义堆栈
        self.stack = QStackedWidget()
        # 定义7个页面,并赋予相应的布局格式
        for i in range(1, 8):
            exec("self.stack{}=QWidget()".format(i))
            exec("self.stack{}ui()".format(i))
            exec("self.stack.addWidget(self.stack{})".format(i))
        # 设置主窗口的水平布局
        vbox = QVBoxLayout()
        vbox.addItem(spacerItem8)
        vbox.addWidget(self.label_title)
        vbox.addItem(spacerItem6)
        vbox.addWidget(self.label_1)
        vbox.addWidget(self.list1)
        vbox.addWidget(self.label_2)
        vbox.addWidget(self.list2)
        subhbox = QHBoxLayout()
        vbox_all = QVBoxLayout()
        subhbox.addItem(spacerItem1)
        subhbox.addItem(spacerItem2)
        subhbox.addWidget(self.pushButton)
        subhbox.addItem(spacerItem4)
        subhbox.addWidget(self.pushButton_3)
        subhbox.addItem(spacerItem5)
        vbox_all.addItem(spacerItem9)
        vbox_all.addLayout(subhbox)
        vbox_all.addItem(spacerItem7)
        vbox_all.addWidget(self.stack)
        hbox = QHBoxLayout()
        hbox.addLayout(vbox)
        hbox.addLayout(vbox_all)
        
        self.setLayout(hbox)
        
        # 实现list按钮与stack页面的关联
        self.list1.currentRowChanged.connect(self.stackDisplay1)
        self.list2.currentRowChanged.connect(self.stackDisplay2)  

    def _close_max_min_icon(self):
        self.pushButton_3.setText('×')
        self.pushButton.setText('—')
        self.pushButton.setStyleSheet('''QPushButton{background:rgb(17,101,154);
                                                     color: white;
                                                     border-radius:5px;}
                                                     QPushButton:hover{background:rgb(186,204,217);}''')
        self.pushButton_3.setStyleSheet('''QPushButton{background:rgb(17,101,154);
                                                      border-radius:5px;
                                                      color: white}
                                                      QPushButton:hover{background:rgb(186,204,217);}''')
        
    @pyqtSlot()
    def on_pushButton_3_clicked(self):
        # 关闭程序
        self.close()
    
    @pyqtSlot()
    def on_pushButton_clicked(self):
        # 最小化
        self.showMinimized()
        
    def mouseMoveEvent(self, e: QMouseEvent):  # 重写移动事件
        self._endPos = e.pos() - self._startPos
        self.move(self.pos() + self._endPos)

    def mousePressEvent(self, e: QMouseEvent):
        if e.button() == Qt.LeftButton:
            self._isTracking = True
            self._startPos = QPoint(e.x(), e.y())

    def mouseReleaseEvent(self, e: QMouseEvent):
        if e.button() == Qt.LeftButton:
            self._isTracking = False
            self._startPos = None
            self._endPos = None

    # 定义list按钮的槽函数
    # 功能：单击list选项 显示相应页面
    def stackDisplay1(self):
        try:
            i = self.list1.currentRow()
            self.stack.setCurrentIndex(i)
        except:
           pass
       
    def stackDisplay2(self):
        try:
            i = self.list2.currentRow()
            self.stack.setCurrentIndex(i + 3)
        except:
           pass


    #页面一的布局设计
    #页面一的功能： 基础运算
    def stack1ui(self):
        layout = QVBoxLayout()
        sublayout = QGridLayout()
        hlayout = QHBoxLayout()
        layout.setContentsMargins(20, 20, 20, 40)
        sublayout.setContentsMargins(0, 20, 0, 0)
        self.operator_stack = []
        self.number_stack = []
        
        #读入qss文件用于按钮美化
        with open('btnQSSforEnglish.qss', 'r') as p:   #导入英文字体的qss样式
            self.stack1_btn_style1 = p.read()
        with open('btnQSSforEnglish2.qss', 'r') as p:   #导入DEL,AC,=,等变色的qss样式
            self.stack1_btn_style2 = p.read()
        with open('btnQSSforChinease.qss', 'r') as p:   #导入按钮中文，橘色背景样式
            self.stack1_btn_style3 = p.read()
        with open('btnQSSforChineaseblue.qss', 'r') as p:   #导入按钮中文，蓝色背景样式
            self.stack1_btn_style4 = p.read()            
        #设置字体大小
        self.font_button = QFont()
        self.font_button.setPointSize(12)

        self.text_edit = QTextEdit()
        #设置text_edit边框圆角、字体、边框颜色
        self.textEditStyle = '''QTextEdit{font-family:UD Digi Kyokasho NK-B;
                                                  border-radius:8px;
                                                  border:2px solid rgb(17, 101, 154);}'''
        self.textEditStyle2 = '''QTextEdit{font-family:12px Microsoft YaHei;
                                                  border-radius:8px;
                                                  border:2px solid rgb(17, 101, 154);}'''        
        self.text_edit.setStyleSheet(self.textEditStyle)
        self.text_edit.setFont(self.font_button)
        self.text_edit.setMaximumSize(730, 150)
        self.text_edit.setReadOnly(True)    #显示结果，访问权限设为：只读
        spacerItemforedit = QtWidgets.QSpacerItem(0, 1, QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Minimum)
        hlayout.addItem(spacerItemforedit)
        hlayout.addWidget(self.text_edit)
        layout.addLayout(hlayout)
        #定义各按键的名称
        names = ['ln', 'e', '√x', 'x^y', 'DEL', 'AC', 'sin', '7', '8', '9', 
                 '(', ')','cos', '4', '5', '6', '+', '-', 'arcsin', '1', '2',
                 '3', '×', '/','arccos', '0', '.', 'π', '%', '=']
        
        #生成各按键的位置
        #按键共有4行9列
        positions = [(i, j) for i in range(5) for j in range(6)]
        #按键的名称与位置对应起来
        for name, position in zip(names, positions):
            button = QPushButton(name)  #生成按键
            button.setStyleSheet(self.stack1_btn_style1)
            if name == 'DEL' or name == 'AC' or name == '=':
                button.setStyleSheet(self.stack1_btn_style2)
            button.setContentsMargins(5, 15, 5, 15)
            button.setMaximumSize(90, 50)
            button.setFont(self.font_button)
            button.clicked.connect(lambda: self.show_msg1())
            sublayout.addWidget(button, *position)   #‘*’将位置元组分成两个值

        layout.addLayout(sublayout)
        self.stack1.setLayout(layout)
        
    #按键响应的槽函数
    #功能:将按键对应的字符显示到屏幕
    def show_msg1(self):
        #每个按钮都连接了show_msg的点击事件
        sender = self.sender()
        sender_text = sender.text()
        #AC/DEL/以及‘=’不显示在屏幕，要进行操作
        #点击AC时的事件，清空text_edit中的内容
        if sender_text == 'AC':
            self.text_edit.clear()
        elif sender_text == 'DEL':
            self.Backspace_1()            
        elif sender_text == '=':
            self.Calculate()
        elif sender_text == 'x^y':
            #如果进行幂操作，屏幕只显示符号^，而不是x^y
            _str = self.text_edit.toPlainText()
            self.text_edit.setText(_str + '^(')
        elif sender_text == '√x':
            #如果进行开根号，屏幕只显示根号，而不是根号x
            _str = self.text_edit.toPlainText()
            self.text_edit.setText(_str + '√(')  
        elif sender_text == 'sin' or sender_text == 'cos'\
            or sender_text == 'arcsin' or sender_text == 'arccos'\
            or sender_text == 'ln':
            _str = self.text_edit.toPlainText()
            self.text_edit.setText(_str + sender_text + '(')
        else:
            _str = self.text_edit.toPlainText()
            self.text_edit.setText(_str + sender_text)
            
    def initConnect_1(self):
        self.text_edit.textChanged.connect(self.cursorChange)
        
    #每次输入都自动滚屏到底
    def cursorChange_1(self):
        print('Cursor change')
        cursor = self.text_edit.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.text_edit.setTextCursor(cursor)
            
    #点击DEL时的事件，删除一个字符
    def Backspace_1(self):
        expression = self.text_edit.toPlainText()
        length = len(expression)
        expression = expression[0:length-1]
        self.text_edit.setText(expression)

    def Calculate(self):
        try:
            formula= self.text_edit.toPlainText()
            #如果只输入了数字，那么计算结果仍为数字
            if re.match('-?[\d+,π,e]\.?\d*$', formula):
                self.text_edit.append(formula + '\n')
                return
            #输入的内容是表达式，屏幕显示计算结果
            #将fomular分割，只留当前行
            length = len(formula)
            i = 0
            flag = False
            #判断现在text_edit是否多行
            while i < length:
                if formula[i] == '\n':
                    flag = True
                    break
                i = i + 1
            if flag:
                formula_split = formula.rsplit('\n', 1)
                formula = formula_split[1]
            #Result_cal为处理表达式formula并返回计算结果的函数
            result = Result_cal(Formula_format(formula))
            self.text_edit.append(result)      
        except:
            self.text_edit.clear()
            self.text_edit.setText('出错啦！请按"AC"键清空，重新输入公式！')

    #页面2的布局设计
    #页面2的功能： 实现矩阵运算
    def stack2ui(self):
        layout = QVBoxLayout()
        sublayout1 = QHBoxLayout()
        sublayout2 = QGridLayout()
        layout.setContentsMargins(20, 10, 20, 30)
        #定义输入输出框的子布局
        #定义text控件
        self.input_edit = QTextEdit()
        self.output_edit = QTextEdit()
        #设置两个框的样式表同基础运算页
        self.input_edit.setStyleSheet(self.textEditStyle)
        self.output_edit.setStyleSheet(self.textEditStyle)
        self.input_edit.setMaximumSize(365, 250)
        self.output_edit.setMaximumSize(365, 250)
        
        self.input_edit.setPlaceholderText('Input matrix:(example)''\n''1 3 3'
                                          '\n''1 2 4''\n''2 3 5''\n''ADD/Minus/Mul/Power记得换行哦！')
        self.output_edit.setPlaceholderText('Output matrix:')
        self.output_edit.setReadOnly(True)

        sublayout1.addWidget(self.input_edit)
        sublayout1.addWidget(self.output_edit)
        
        #定义按键操作框的子布局
        #定义按钮控件
        names = ['AC', 'Answer',
                 'DEL', 'Add', 'Minus', 'Mul', 
                 'Inv', 'Rank', 'Power', 'Tran', 
                 'Simplest','Det', 'Eigenval','Eigenvect']
        positions = [(0, 0), (0, 5), (1, 0), (1, 1), (1, 2), (1, 3),(1, 4), 
                     (1, 5), (2, 0), (2, 1), (2, 2), (2, 3), (2, 4),(2, 5)]
        #循环实现布局
        for name, position in zip(names, positions):
            button = QPushButton(name)
            button.setStyleSheet(self.stack1_btn_style1)#类似于第一页的按钮样式
            if name == 'DEL' or name == 'AC' or name == 'Answer':
                button.setStyleSheet(self.stack1_btn_style2)
            button.setContentsMargins(5, 15, 5, 15)
            button.setMaximumSize(100, 50)
            button.setFont(self.font_button)
            button.clicked.connect(lambda: self.show_msg2())
            sublayout2.addWidget(button, *position)
        #将子布局合并为一个完整的布局
        layout.addLayout(sublayout1)
        layout.addLayout(sublayout2)
        self.stack2.setLayout(layout)
        
    #按键响应的槽函数
    #功能:在屏幕显示操作，进行计算，在output框中显示结果
    def show_msg2(self):
        #获取按键名称
        sender = self.sender()
        sender_text = sender.text()
        #清空屏幕
        if sender_text == 'AC':
            self.input_edit.clear()
            self.output_edit.clear()
        #处理加减乘幂操作，在output edit中显示计算结果
        if sender_text == 'Answer':
            self.Answer_output()
        #退格，删除一个字符
        if sender_text == 'DEL':
            self.Backspace_2()
        if sender_text == 'Add':
            self.input_edit.append('+')
        if sender_text == 'Minus':
            self.input_edit.append('-') 
        if sender_text == 'Mul':
            self.input_edit.append('*')
        if sender_text == 'Power':
            self.input_edit.append('^')
        if sender_text == 'Inv':
            self.Reverse_op()
        if sender_text == 'Rank':
            self.Rank_op()
        if sender_text == 'Tran':
            self.Transpose_op()
        if sender_text == 'Simplest':
            self.Rref_op()
        if sender_text == 'Det':
            self.Det_op()
        if sender_text == 'Eigenval':
            self.Eigenval_op()
        if sender_text == 'Eigenvect':
            self.Eigenvect_op()
    
    def initConnect(self):
        self.input_edit.textChanged.connect(self.cursorChange)
        
    #每次输入都自动滚屏到底
    def cursorChange(self):
        print('Cursor change')
        cursor = self.input_edit.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.input_edit.setTextCursor(cursor)

    #退格操作
    def Backspace_2(self):
        expression = self.input_edit.toPlainText()
        length = len(expression)
        expression = expression[0:length-1]
        self.input_edit.setText(expression) 
    
    #矩阵加减、乘、幂次运算    
    def Answer_output(self):
        text = self.input_edit.toPlainText()
        length = len(text)
        try:
            matrix = Cal_four_op(text)#详见matrix_operations.py
            self.output_edit.setPlainText(matrix)
        except:
            self.output_edit.setPlainText('出错啦！请检查矩阵是否正确！')
      
    #求矩阵的逆矩阵
    def Reverse_op(self):
        text = self.input_edit.toPlainText()
        listForMat = formatInput(text) #处理输入内容，具体函数实现在matrix_operations.py
        A = Matrix(listForMat)
        # 不是方阵或者不满秩 无法求逆
        if A.shape[0] != A.shape[1] or A.rank() != A.shape[0]:
            self.output_edit.setText('您输入的矩阵无法求逆，请按Clear键清空！')
            return
        reverse_A = A ** -1
        output = formatOutput(reverse_A)#处理计算后的矩阵，具体函数实现在matrix_operations.py
        #将结果输出到右边的结果框
        self.output_edit.setPlainText(output) 
    
    #求矩阵的秩
    def Rank_op(self):
        text = self.input_edit.toPlainText()
        listForMat = formatInput(text)
        A = Matrix(listForMat)
        
        rank = A.rank()
        output = str(rank)
        self.output_edit.setPlainText(output)
    
    #转置操作
    def Transpose_op(self):
        text = self.input_edit.toPlainText()
        listForMat = formatInput(text)
        A = Matrix(listForMat)
        A = Matrix(A)
        transpose_A = A.T
        output = formatOutput(transpose_A)

        self.output_edit.setPlainText(output)
    
    #求矩阵的最简型    
    def Rref_op(self):
        text = self.input_edit.toPlainText()
        listForMat = formatInput(text)
        A = Matrix(listForMat)

        rrf_matrix = A.rref()[0]
        output = formatOutput(rrf_matrix)
        self.output_edit.setPlainText(output)
     
    #求矩阵的行列式
    def Det_op(self):
        text = self.input_edit.toPlainText()
        listForMat = formatInput(text)
        A = Matrix(listForMat)
        # 不是方正没法求行列式
        if A.shape[0] != A.shape[1]:
            self.output_edit.setText('您输入的矩阵无法求行列式，请按Clear键清空！')
            return
        det = A.det()
        output = str(det)
        self.output_edit.setPlainText(output)
    
    #求矩阵的特征值    
    def Eigenval_op(self):
        text = self.input_edit.toPlainText()
        listForMat = formatInput(text)
        A = Matrix(listForMat)
        # 不是方阵没法求特征值
        if A.shape[0] != A.shape[1]:
            self.output_edit.setText('您输入的矩阵无法求特征值，请按Clear键清空！')
            return
        eigenvalmap = A.eigenvals()
        output = ''
        for val, num in eigenvalmap.items():
            for i in range(num):
                output += str(val) + '\n'
        self.output_edit.setPlainText(output)
    
    #求特征向量
    def Eigenvect_op(self):
        text = self.input_edit.toPlainText()
        listForMat = formatInput(text)
        A = Matrix(listForMat)
        # 不是方阵没法求特征向量
        if A.shape[0] != A.shape[1]:
            self.output_edit.setText('您输入的矩阵无法求特征向量，请按Clear键清空！')
            return
        eigenvectList = A.eigenvects()
        output = ''
        #对每个特征值分别求特征向量
        for i in range(len(eigenvectList)):
            output += '特征值:' + str(eigenvectList[i][0])
            output += '\n数量:' + str(eigenvectList[i][1])
            output += '\n特征向量: \n'
            for j in range(len(eigenvectList[i][2])):# 可能有多个特征向量
                output += formatOutput(eigenvectList[i][2][j]) + '\n'
                output += '\n \n'
            output += '\n'

        self.output_edit.setPlainText(output)

    # 页面三的布局设计
    # 页面三的功能： 绘制函数图像
    def stack3ui(self):
        layout = QHBoxLayout()
        sublayout = QGridLayout()
        sublayout1 = QVBoxLayout()
        layout.setContentsMargins(20, 10, 20, 40)
        sublayout.setContentsMargins(20, 0, 20, 0)
        sublayout1.setContentsMargins(0, 0, 20, 0)
        
        #定义绘图区标签和标题
        figureEdit = QLabel('')
        figure_Edit_title = QLabel('绘图区：')
        #设置标签大小
        figure_Edit_title.setMaximumSize(100, 25)
        sublayout1.addWidget(figure_Edit_title)
        figureEdit.setMinimumWidth(350)
        figureEdit.setFrameStyle(1)
        # 定义注释控件
        funcLabel = QLabel('请输入函数：')
        lowerBoundLabel = QLabel('区间左端点：')
        upperBoundLabel = QLabel('区间右端点：')
        lowerBoundLabel.setContentsMargins(0, 20, 10, 0)
        upperBoundLabel.setContentsMargins(10, 20, 0, 0)
        lowerBoundLabel.setMinimumHeight(20)
        upperBoundLabel.setMinimumHeight(20)
        # 定义输入控件
        funcEdit = QTextEdit()
        #修改funcEdit样式
        funcEdit.setStyleSheet(self.textEditStyle2)
        funcEdit.setPlaceholderText("目前仅支持自变量为x的一元函数，且无需输入“y=”!\n注意幂运算符要输入**哦!")
        # 定义用户输入绘图区间的控件
        lowerBoundEdit = QLineEdit()
        upperBoundEdit = QLineEdit()
        lowerBoundEdit.setMinimumSize(60, 60)
        upperBoundEdit.setMinimumSize(60, 60)
        upperBoundEdit.setContentsMargins(10, 0, 0, 20)
        lowerBoundEdit.setContentsMargins(0, 0, 10, 20)
        # 绘图区间默认值为[-5,5]
        lowerBoundEdit.setPlaceholderText('-5')
        upperBoundEdit.setPlaceholderText('5')
        # 定义绘图按键
        plotButton = QPushButton('点我开始绘图')
        plotButton.setMinimumSize(60, 40)

        #定义LineEdit和Label样式表，并添加到控件上
        self.LineEditStyle = '''QLineEdit{font-family:Microsoft YaHei;
                                                  border-radius:8px;
                                                  border:2px solid rgb(17, 101, 154);}'''  
        self.font_Edit = QFont()
        self.font_Edit.setFamily("SimHei") #设置字体
        self.font_Edit.setPointSize(10)
        self.font_Edit.setBold(75)

        self.QLabelStyle = '''QLabel{font-family: Microsoft YaHei;
                                                  border-radius:8px;
                                                  border:2px solid rgb(17, 101, 154);}''' 
        #设置标签/LineEdit/按钮样式
        figureEdit.setStyleSheet(self.QLabelStyle)
        lowerBoundEdit.setStyleSheet(self.LineEditStyle)
        lowerBoundEdit.setFont(self.font_Edit)
        upperBoundEdit.setStyleSheet(self.LineEditStyle)
        upperBoundEdit.setFont(self.font_Edit)
        #设置字体
        funcLabel.setFont(self.font_title)
        figure_Edit_title.setFont(self.font_title)
        lowerBoundLabel.setFont(self.font_title)
        upperBoundLabel.setFont(self.font_title)
        funcEdit.setFont(self.font_Edit)
        plotButton.setStyleSheet(self.stack1_btn_style3)
        plotButton.setFont(self.font_Edit)
        
        # 对子布局的控件进行排列
        sublayout.addWidget(funcLabel, 1, 0, 1, 2)
        sublayout.addWidget(funcEdit, 2, 0, 1, 2)
        sublayout.addWidget(lowerBoundLabel, 3, 0, 1, 1)
        sublayout.addWidget(upperBoundLabel, 3, 1, 1, 1)
        sublayout.addWidget(lowerBoundEdit, 4, 0, 1, 1)
        sublayout.addWidget(upperBoundEdit, 4, 1, 1, 1)
        sublayout.addWidget(plotButton, 5, 0, 1, 2)

        # 绘图按钮与画图函数连接起来
        plotButton.clicked.connect(lambda: self.plot_image(funcEdit, upperBoundEdit, lowerBoundEdit, figureEdit))

        # 设置总布局
        layout.addLayout(sublayout)
        sublayout1.addWidget(figureEdit)
        layout.addLayout(sublayout1)
        # 将总布局应用到stack3
        self.stack3.setLayout(layout)

    # 绘图按钮的槽函数
    # 函数功能： 依据输入进行绘图，并插入到页面中
    def plot_image(self, fEdit, uBoundEdit, lBoundEdit, outWin):
        # 获取函数
        if fEdit.toPlainText() == '':
            outWin.setText('未输入函数表达式')
            return
        # 获取用户输入的绘图区间，默认[-5,5]
        a = -5 if lBoundEdit.text()=='' else eval(lBoundEdit.text())
        b = 5 if uBoundEdit.text()=='' else eval(uBoundEdit.text())
        if a >= b:
            outWin.setText('输入的区间不符合要求')
            return
        stepSize = min(0.1, (b-a)/100)
        X = list(np.arange(a, b, stepSize))     #定义域
        try:
            Y = list(eval(fEdit.toPlainText()) for x in X)  # 值域
        except:
            outWin.setText('输入的公式不符合要求，请重新输入！\n 检查输入的公式是否是一元变量x的多项式，且幂运算符为**')
        else:
            plt.figure()
            plt.plot(X, Y)
            plt.xlabel('x')
            plt.ylabel('y= '+fEdit.toPlainText())
            plt.savefig('figure.jpg')       #将图像保存为图片
            png = QPixmap('figure.jpg')     #将图片插入到窗口
            outWin.setPixmap(png)

    # 页面4的布局设计
    # 页面4的功能：系统时间与天气查询
    def stack4ui(self):
        # 定义样式表
        self.QLabelStyle_stack4_1 = '''QLabel{font-family: Microsoft YaHei;
                                                font-size:30px;
                                                font-weight:900;
                                                color: rgb(17, 101, 154);}'''
        self.QLabelStyle_stack4_2 = '''QLabel{font-family: Microsoft YaHei;
                                                font-size:20px;
                                                color: rgb(17, 101, 154);}'''

        self.font_Label = QFont()
        self.font_Label.setFamily("SimHei")     # 设置字体
        self.font_Label.setPointSize(9)
        
        self.font_Label2 = QFont()
        self.font_Label2.setFamily("SimHei")    # 设置字体
        self.font_Label2.setPointSize(10)

        layout = QVBoxLayout()
        # 定义显示时间的控件
        dateEdit = QLabel()
        # 定义计时器,实时更新时间
        timer = QTimer(self)
        dateEdit.setStyleSheet(self.QLabelStyle_stack4_1)   # 设置样式
        timer.timeout.connect(lambda: self.time_show(dateEdit))
        timer.start()
        # 显示地图控件,默认上海
        geoView = QWebEngineView()
        self.ak = 'hIcKLMGeLiXnBvineSmniHahhgqHlsqZ'
        address = "http://api.map.baidu.com/geocoder?location=%s,%s&coord_type=wgs84&output=html&src=cityMap" % (121.480237, 31.236305)
        url = QUrl(address)
        geoView.load(url)
        # 定义天气查询标签控件
        weatherLabel = QLabel('近5天的天气查询')
        weatherLabel.setStyleSheet(self.QLabelStyle_stack4_1)
        # 定义子布局
        # 功能： 显示未来5天天气情况的查询结果
        weatherHbox = QHBoxLayout()
        for i in range(5):     # 定义5个label 放置查询结果
            day = QLabel()
            day.setStyleSheet(self.QLabelStyle)
            day.setFont(self.font_Label)
            day.setFrameStyle(1)
            day.setFixedSize(150, 150)
            weatherHbox.addWidget(day)
        # 定义子布局
        # 功能： 查询向导，获取城市名称
        cityHbox = QHBoxLayout()
        cityLabel = QLabel('城市名：')
        cityLabel.setStyleSheet(self.QLabelStyle_stack4_2)
        cityEdit = QLineEdit()
        cityEdit.setStyleSheet(self.LineEditStyle)
        cityEdit.setFont(self.font_Label2)
        cityEdit.setFixedHeight(40)
        cityEdit.setMaximumWidth(600)
        cityEdit.setPlaceholderText('请输入全称，例如上海市、昌吉回族自治州')
        weatherButton = QPushButton('☀查询')
        weatherButton.setStyleSheet(self.stack1_btn_style4)
        weatherButton.setFixedHeight(40)

        # 将城市名和天气查询与更新地图槽函数链接
        weatherButton.clicked.connect(lambda: self.find_city(cityEdit, weatherHbox))
        weatherButton.clicked.connect(lambda: self.show_map(cityEdit, geoView))

        cityHbox.addWidget(cityLabel)
        cityHbox.addWidget(cityEdit)
        cityHbox.addWidget(weatherButton)
        # 总布局的控件排列
        layout.addWidget(dateEdit)
        layout.addWidget(geoView)
        layout.addWidget(weatherLabel)
        layout.addLayout(cityHbox)
        layout.addLayout(weatherHbox)
        # 将总布局应用到页面4
        self.stack4.setLayout(layout)
        
        #控件大小/间距
        layout.setContentsMargins(30, 10, 30, 40)
        geoView.setMaximumSize(800, 200)
        cityEdit.setContentsMargins( 20, 0, 30, 0)
        weatherButton.setContentsMargins(30, 0, 30, 0)

    # 更新当前时间的槽函数
    # 功能： 每隔一秒钟，更新一次当前时间
    def time_show(self, dateEdit):
        dateEdit.setText(QDateTime.currentDateTime().toString('yyyy/MM/dd hh:mm:ss dddd'))
        self.sender().start(1000)

    # 天气预报的槽函数
    # 功能： 依据输入的城市名，找到对应的天气预报信息，并输出
    def find_city(self, cityBtn, hbox):
        city_name = cityBtn.text()
        try:        # 测试城市名是否有效
            weather_url = 'http://wthrcdn.etouch.cn/weather_mini?city={}'.format(city_name)
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.70 Safari/537.36'}
            city_response = requests.get(weather_url, headers=headers)
            weather_dict = json.loads(city_response.text)
            forecast_weather = weather_dict.get('data').get('forecast')
        except:
            for i in range(5):
                hbox.itemAt(i).widget().setText('城市名无效!')
        else:
            # 生成未来5天天气情况列表
            day = []
            for i in range(5):
                day.append('日期:' + forecast_weather[i].get('date') + '\n' \
                           + '最高温度:' + forecast_weather[i].get('high') + '\n' \
                           + '最低温度:' + forecast_weather[i].get('low') + '\n' \
                           + '风向:' + forecast_weather[i].get('fengxiang') + '\n' \
                           + '风力:' + forecast_weather[i].get('fengli') + '\n' \
                           + '天气状况:' + forecast_weather[i].get('type') + '\n')
            # 写入到 查询结果子布局
            for i in range(5):
                hbox.itemAt(i).widget().setText(day[i])

    # 显示地图的槽函数
    # 功能： 定位到用户查询的城市，显示地图
    def show_map(self, cityEdit, geoView):
        city_name = cityEdit.text()
        try:
            # 根据城市名 获得其经纬度
            geo_url = 'http://api.map.baidu.com/geocoder?address='+city_name+'&output=json&key='+ self.ak
            geo = requests.get(geo_url)
            loc = geo.json()
            lat = float(loc['result']['location']['lat'])   # 纬度
            lng = float(loc['result']['location']['lng'])   # 经度
            print(city_name);print(lat);print(lng)
            # 根据经纬度 在地图上定位
            city = "http://api.map.baidu.com/geocoder?location=%s,%s&coord_type=wgs84&output=html&src=cityMap" % (lat, lng)
            city_url = QUrl(city)
            geoView.load(city_url)
        except:
            print('error')
            return

    # 页面5的布局设计
    # 功能： 帮你做决定今天吃什么，及其他犹豫不决的事情
    def stack5ui(self):
        layout = QVBoxLayout()
        foodSublayout = QGridLayout()       # 决定吃什么的子布局
        answerSublayout = QGridLayout()       # 答案之书的子布局
        # 定义决定吃什么的子布局
        foodLabel = QLabel()
        foodLabel.setAlignment(Qt.AlignCenter)
        foodLabel.setFrameStyle(1)
        foodBtn = QPushButton("帮我决定")
        addFoodEdit = QLineEdit()
        addFoodEdit.setPlaceholderText('想吃点别的？在这里添加自定义食物!')
        addFoodEdit.setAlignment(Qt.AlignCenter)
        addFoodBtn = QPushButton('立即添加')
        # 食物数据库的文件名
        foodFile = 'foodList.csv'
        # 按键与相应的槽函数链接
        foodBtn.clicked.connect(lambda: self.findFood(foodFile, foodLabel))
        addFoodBtn.clicked.connect(lambda: self.addFood(foodFile, addFoodEdit))
        # 食物子布局的控件排列
        foodSublayout.addWidget(foodLabel, 0, 0)
        foodSublayout.addWidget(foodBtn, 1, 0)
        foodSublayout.addWidget(addFoodEdit, 0, 1)
        foodSublayout.addWidget(addFoodBtn, 1, 1)
        
        # 定义答案之书的子布局
        answerIntroLabel = QLabel('STEP1:您需要在心里想一个困扰多时的问题。\n\nEg:“我该追求她吗？”“我软工能拿4.0吗？”\n\n'
                                  'STEP2:点击“帮我决定”，您将会看到问题的答案。')
        answerIntroLabel.setAlignment(Qt.AlignCenter)
        answerLabel = QLabel()
        answerLabel.setAlignment(Qt.AlignCenter)
        answerLabel.setFrameStyle(1)
        answerBtn = QPushButton('帮我决定')
        # 答案之书的文件名
        answerFile = 'answers.csv'
        # 按键与槽函数链接
        answerBtn.clicked.connect(lambda: self.findAnswer(answerFile, answerLabel))
        # 答案之书子布局的控件排列
        answerSublayout.addWidget(answerLabel, 0, 0)
        answerSublayout.addWidget(answerBtn, 1, 0)
        # 总布局设计
        foodTitle = QLabel('☺今天吃什么')
        layout.addWidget(foodTitle)
        layout.addLayout(foodSublayout)
        answerTitle = QLabel('☻我该怎么办')
        layout.addWidget(answerTitle)
        layout.addWidget(answerIntroLabel)
        layout.addLayout(answerSublayout)
        # 将总布局应用到页面5
        self.stack5.setLayout(layout)
        #控件美化
        #定义标签样式表
        self.QLabelStyle_stack5_1 = '''QLabel{font-family: Microsoft YaHei;
                                                font-size:40px;
                                                font-weight:900;
                                                color: rgb(17, 101, 154);}'''
        self.QLabelStyle_stack5_2 = '''QLabel{font-family: Microsoft YaHei;
                                                font-size:15px;
                                                font-weight:bold;
                                                color: rgb(17, 101, 154);}'''  
        #添加标签样式
        foodTitle.setStyleSheet(self.QLabelStyle_stack5_1)
        answerTitle.setStyleSheet(self.QLabelStyle_stack5_1)
        answerIntroLabel.setStyleSheet(self.QLabelStyle_stack5_2)
        foodLabel.setStyleSheet(self.QLabelStyle)
        foodLabel.setFont(self.font_Edit)
        addFoodEdit.setStyleSheet(self.LineEditStyle)
        addFoodEdit.setFont(self.font_Edit)
        answerLabel.setStyleSheet(self.QLabelStyle)
        answerLabel.setFont(self.font_Edit)
        #添加按钮样式
        foodBtn.setStyleSheet(self.stack1_btn_style3)
        addFoodBtn.setStyleSheet(self.stack1_btn_style3)
        answerBtn.setStyleSheet(self.stack1_btn_style3)
        #控件间距
        layout.setContentsMargins(40, 0, 40, 40)
        foodLabel.setMinimumSize(300, 80)#标签大小
        foodLabel.setMaximumSize(300, 80)
        addFoodEdit.setMaximumSize(300, 80)#lineedit大小
        answerLabel.setMinimumSize(660, 80)
        answerLabel.setMaximumSize(660, 80)
        
    # 随机生成食物的槽函数
    # 功能： 随机选取食物，并显示
    def findFood(self, filename, foodLabel):
        # 打开文件，并读成list形式
        file = open(filename, 'r')
        csvReader = csv.reader(file)
        foodList = list(csvReader)
        # 以系统时间为种子，随机生成下标
        seed(time())
        index = randint(0, len(foodList)-1)
        foodLabel.setText(str(foodList[index]))     # 将随机选中的食物显示到页面
        # 关闭文件
        file.close()

    # 定义自定义添加食物的槽函数
    # 功能： 用户输入食物，并添加到csv文件中
    def addFood(self, filename, foodEdit):
        # 打开文件，“读文件”是为了查询，“写文件”是为了写入
        file_r = open(filename, 'r')
        file_w = open(filename, 'a', encoding='utf-8', newline='')
        # 根据获得的输入，转化成csv能够识别的格式
        food = []
        food.append(foodEdit.text())
        foodEdit.clear()
        # csv读写工具
        csvReader = csv.reader(file_r)
        foodList = list(csvReader)
        csvWriter = csv.writer(file_w)
        # 检查获得的输入，是否已经存在于csv中，若不存在，则添加至末尾
        if food in foodList:
            foodEdit.setPlaceholderText('已存在！请继续输入')
        else:
            csvWriter.writerow(food)
            foodEdit.setPlaceholderText('添加成功！请继续输入')
        # 关闭文件
        file_r.close()
        file_w.close()

    # 随机生成答案的槽函数
    # 功能： 点击“帮我决定”，随机选择答案，并输出
    def findAnswer(self, filename, answerLabel):
        # 打开文件，并读成列表
        file = open(filename, 'r')
        csv_reader = csv.reader(file)
        answerList = list(csv_reader)
        # 以系统时间为种子，随机获得答案，并输出到页面
        seed(time())
        index = randint(0, len(answerList)-1)
        answerLabel.setText(str(answerList[index]))
        # 关闭文件
        file.close()

    # 页面6的布局设计
    # 功能： 实现24点游戏
    def stack6ui(self):
        layout = QVBoxLayout()
        card_layout = QHBoxLayout()
        op_layout = QGridLayout()

        # 纸牌的图片的文件名，存放于根目录下
        card_figure = ['card_background.jpg', 'cardA.jpg', 'card2.jpg', 'card3.jpg',
                       'card4.jpg', 'card5.jpg', 'card6.jpg', 'card7.jpg', 'card8.jpg',
                       'card9.jpg', 'card10.jpg', 'cardJ.jpg', 'cardQ.jpg', 'cardK.jpg']
        # 设置显示卡片的子布局
        # 定义显示卡片的控件
        card1 = QLabel('卡片1')
        card2 = QLabel('卡片2')
        card3 = QLabel('卡片3')
        card4 = QLabel('卡片4')

        for card in [card1, card2, card3, card4]:
            card.setFixedSize(150, 200)
            card.setFrameStyle(1)
            card.setStyleSheet("border-image:url('card_background.jpg')")
            card_layout.addWidget(card)

        # 设置操作区域的子布局
        # 定义控件
        introStr = ' 24点游戏规则：\n 1.点击”开始游戏“，随机发放4张扑克牌;\n' \
                   '（其中A对应1，J对应11，Q对应12，K对应13） \n' \
                   ' 2.仅允许使用“+，-，*，/，**，（）”运算符;\n 3.要求最终的运算结果为24。 \n' \
                   ' 注意：4张纸牌的数字都要使用且每张只允许使用1次；\n\t游戏允许重复提交。 '
        introLabel = QLabel(introStr)   # 游戏规则
        introLabel.setFont(self.font_Label2)
        outputLabel = QLabel()     # 显示结果
        outputLabel.setFont(self.font_Label2)
        outputLabel.setContentsMargins(30, 0, 30, 0)
        startButton = QPushButton('♤开始游戏')      # 开始按钮
        startButton.setStyleSheet(self.stack1_btn_style4)
        inputEdit = QLineEdit()     # 输入框
        inputEdit.setPlaceholderText('在此输入您的公式，注意需切换至英文。')
        inputEdit.setStyleSheet(self.LineEditStyle)
        inputEdit.setFont(self.font_Label2)
        submitButton = QPushButton('▷提交')       # 提交按钮
        submitButton.setStyleSheet(self.stack1_btn_style4)

        # 将控件插入操作子布局
        op_layout.addWidget(introLabel, 0, 0, 1, 3)
        op_layout.addWidget(startButton, 0, 3)
        op_layout.addWidget(inputEdit, 1, 0, 1, 3)
        op_layout.addWidget(submitButton, 1, 3)
        op_layout.addWidget(outputLabel, 2, 0, 1, 3)

        startButton.clicked.connect(lambda: self.start24Click([card1, card2, card3, card4], card_figure, inputEdit))
        submitButton.clicked.connect(lambda: self.submit24Click(inputEdit, outputLabel, [card1, card2, card3, card4]))

        # 设置总布局
        layout.addLayout(card_layout)
        layout.addLayout(op_layout)
        # 将总布局应用到页面6
        self.stack6.setLayout(layout)
        
        #控件间距
        layout.setContentsMargins(30, 30, 30, 40)
        startButton.setMinimumSize(110, 40)
        startButton.setMaximumSize(110, 40)
        submitButton.setMinimumSize(110, 40)
        submitButton.setMaximumSize(110, 40)
        inputEdit.setMinimumSize(100, 40)
        introLabel.setContentsMargins(30, 30, 30, 20)
        inputEdit.setContentsMargins(30, 0, 30, 0)

    # 开始按键的槽函数
    # 功能： 单击“开始游戏”按键， 发牌
    def start24Click(self, cd, cd_figure, inputEdit):
        # 以系统时间为随机数种子，随机发4张牌
        seed(time())
        for i in range(4):
            num = randint(1, 13)
            cd[i].setText(str(num))
            cd[i].setStyleSheet("border-image:url('"+cd_figure[num]+"')")
        # 清空输入框
        inputEdit.clear()

    # 提交键槽函数
    # 功能： 单击“提交”按键，检验用户输入的公式是否符合规则且结果为24，并输出
    def submit24Click(self, inLine, outLabel, cd):
        inStr = inLine.text()
        # 储存允许存在于公式中的字符
        ch_valid = ['+', '-', '*', '/', '(', ')', '1']   # 1用作十位的抵消
        for card in cd:
            ch_valid.append(card.text())    # 将纸牌上的数字放入
        # 检验输入的公式是否符合游戏规则
        preCh = '0'   # 记录前一个字符，前一个字符为1时，可能将会组成一个两位数
        for ch in inStr:
            try:
                eval(ch)      # 运算符等特殊符号eval后报错
            except:        # 检查是否为有效字符
                if ch_valid.count(ch) == 0:
                    outLabel.setText('抱歉，您的输入不符合游戏规则！')
                    return
            else:
                try:
                    eval(preCh)
                except: pass
                else:
                    if (eval(preCh) in range(1, 100)) and (eval(ch) in range(10)):
                        # 此时前一字符为有效的一位数或两位数，后面在紧跟一个数字，组成一个两位数或三位数,不能拆开
                        ch = preCh + ch
                        if eval(ch) in range(10, 14):
                            ch_valid.append('1')    # 此时为有效两位数（10~13），弥补前一字符（即十位’1‘）在前一循环的删除操作
               # 检查是否为有效字符
                finally:
                    if ch_valid.count(ch) == 0:
                        outLabel.setText('抱歉，您的输入不符合游戏规则！')
                        return
                    if eval(ch) in range(1, 14):    # 若是有效数字，将其从有效字符中删除； 有效运算符则不删除
                        ch_valid.remove(ch)
            finally:
                preCh = ch  # 更新前一个字符，以便进入下一个循环
        # 检验纸牌上的数字是否都用了
        if ch_valid != ['+', '-', '*', '/', '(', ')', '1']:
            outLabel.setText('抱歉，您未使用所有纸牌的数字！')
            return
        # 检验输入的公式结果是否为24
        try:
            eval(inStr)
        except:
            outLabel.setText('抱歉，您输入的公式无法运算，请检查你的公式！')
        else:
            if eval(inStr) == 24:
                outLabel.setText('恭喜，您成功了！')
            else:
                outLabel.setText('抱歉，您输入的公式结果为{}，不等于24！'.format(eval(inStr)))

    # 页面7的布局设计
    # 功能： 实现打地鼠游戏
    def stack7ui(self):
        # 定义布局
        layout = QHBoxLayout()      # 总布局
        gameSublayout = QGridLayout()   # 游戏界面子布局
        introSublayout = QVBoxLayout()  # 说明界面子布局

        holes = []   # 存储各地洞的控件，便于参数传递
        flags = []   # 存储各地洞的状态，flag[i]=1 表示第i个地洞有老鼠
        # 将地洞定义为按钮控件
        for i in range(25):
            exec("mouse{}Btn=QPushButton()".format(i))
            exec("mouse{}Btn.setFixedSize(80, 80)".format(i))   # 设置地洞控件大小
            exec("mouse{}Btn.setStyleSheet('border-image:url({})')".format(i, 'hole.jpg'))  # 地洞图片，置于根目录下
            exec("holes.append(mouse{}Btn)".format(i))       # 将地洞控件加入holes
            flags.append(0)     # 默认无老鼠
        # 将地洞控件放至游戏子布局
        for i in range(5):
            for j in range(5):
                x = 5*i+j
                exec("gameSublayout.addWidget(mouse{}Btn, {}, {})".format(x, i, j))

        # 定义 说明子布局的各控件
        self.onGaming = 0  # 是否在“游戏中"状态，onGaming=1表示目前正在游戏中
        self.score = 0  # 击中老鼠次数
        self.missing = 0    # 逃离老鼠次数
        startBtn = QPushButton("▷开始游戏")
        startBtn.setFixedSize(110, 40)
        startBtn.setStyleSheet(self.stack1_btn_style4)
        scoreLabel = QLabel('击中数')
        scoreLabel.setFixedSize(100, 30)
        scoreLabel.setStyleSheet(self.QLabelStyle_stack4_2)
        scoreEdit = QLabel()
        scoreEdit.setFixedSize(60, 30)
        scoreEdit.setStyleSheet(self.QLabelStyle)
        scoreEdit.setFont(self.font_Edit)
        scoreEdit.setFrameStyle(1)
        missingLabel = QLabel('逃离数')
        missingLabel.setFixedSize(100, 30)
        missingLabel.setStyleSheet(self.QLabelStyle_stack4_2)
        missingEdit = QLabel()
        missingEdit.setFixedSize(60, 30)
        missingEdit.setStyleSheet(self.QLabelStyle)
        missingEdit.setFont(self.font_Edit)
        missingEdit.setFrameStyle(1)
        remainingTimeLabel = QLabel('剩余时间')
        remainingTimeLabel.setFixedSize(100, 30)
        remainingTimeLabel.setStyleSheet(self.QLabelStyle_stack4_2)
        remainingTimeEdit = QLabel()
        remainingTimeEdit.setFixedSize(60, 30)
        remainingTimeEdit.setStyleSheet(self.QLabelStyle)
        remainingTimeEdit.setFont(self.font_Edit)
        remainingTimeEdit.setFrameStyle(1)
        # 将控件放到说明子布局
        introSublayout.addWidget(startBtn)
        introSublayout.addWidget(scoreLabel)
        introSublayout.addWidget(scoreEdit)
        introSublayout.addWidget(missingLabel)
        introSublayout.addWidget(missingEdit)
        introSublayout.addWidget(remainingTimeLabel)
        introSublayout.addWidget(remainingTimeEdit)
        # 计时器
        timer = QTimer()  # 全局计时器
        mouseTimer = QTimer()  # 地鼠出现时间计时器
        remainingTimer = QTimer()   # 剩余时间更新计时器
        # 信号与槽函数
        startBtn.clicked.connect(lambda: self.gameStart(holes, flags, timer, mouseTimer, remainingTimer, scoreEdit, missingEdit))  # 开始游戏
        timer.timeout.connect(lambda: self.gameEnd(timer, mouseTimer, holes))  # 游戏时间结束
        for btn in holes:
            btn.clicked.connect(lambda: self.hit( holes, flags, mouseTimer, scoreEdit))
        mouseTimer.timeout.connect(lambda: self.mouseTimeout(holes, flags, missingEdit))  # 一轮老鼠显示时间结束
        remainingTimer.timeout.connect(lambda: self.show_remainingTime(timer, remainingTimeEdit))   # 每秒刷新剩余时间
        # 定义总布局，并应用至页面7
        layout.addLayout(gameSublayout)
        layout.addLayout(introSublayout)
        self.stack7.setLayout(layout)
        
        #控件大小/间隔
        layout.setContentsMargins(0, 20, 0, 20)
        scoreEdit.setMinimumSize(110, 40)
        missingEdit.setMinimumSize(110, 40)
        remainingTimeEdit.setMinimumSize(110, 40)
        
    # 打地鼠游戏开始槽函数
    # 功能：单击“开始游戏”按键，开始计时
    def gameStart(self, holes, flags, timer, mouseTimer, remainingTimer, scoreEdit, missingEdit):
        if self.onGaming == 1:   # 如果正在游戏中，点击开始游戏按钮无响应
            return
        # 初始化得分, 将该地洞设置成无老鼠状态, 状态设置成”游戏中“
        self.score = 0
        scoreEdit.setText(str(self.score))
        self.missing = 0
        missingEdit.setText(str(self.missing))
        self.onGaming = 1
        for index in range(25):
            holes[index].setStyleSheet('border-image:url("hole.jpg")')
            flags[index] = 0
        # 单位毫秒 1000为1秒
        timer.start(30*1000)  # 游戏总时长30秒
        mouseTimer.start(1.5*1000)    # 老鼠出现的时长1.5秒
        remainingTimer.start(1000)  # 剩余时长每一秒更新一次
        self.setCursor(QCursor(QPixmap("hammer.png")))      # 将鼠标设成锤子形状

    # 打地鼠游戏结束槽函数
    # 功能：游戏时间到后，计数器停止工作，状态设为未在游戏中, 显示”game over“
    def gameEnd(self, timer, mouseTimer, holes):
        timer.stop()
        mouseTimer.stop()
        self.onGaming = 0
        self.setCursor(Qt.ArrowCursor)
        holes[11].setStyleSheet('border-image:url("black_game.png")')
        holes[12].setStyleSheet('border-image:url("black.png")')
        holes[13].setStyleSheet('border-image:url("black_over.png")')

    # 打击动作的槽函数
    # 功能： 若打击的是老鼠，则积一分，并随机挑选地洞显示新的老鼠
    def hit(self, holes, flags, mouseTimer, scoreEdit):
        if self.onGaming == 0:  # 状态为”未在游戏中“时，按键无响应
            return
        sender = self.sender()
        index = holes.index(sender)     # 找出是哪个地洞被打击
        if flags[index] == 0:       # 检查该地洞是否有老鼠
            return
        holes[index].setStyleSheet('border-image:url("hittedMouse.jpg")')
        mouseTimer.stop()
        flags[index] = 0.5      # 将该地洞设置成老鼠被打的状态
        self.score += 1      # 积一分
        scoreEdit.setText(str(self.score))
        # 以系统时间为种子，随机选取一个地洞安排老鼠
        seed(time())
        index = randint(0, 24)
        holes[index].setStyleSheet('border-image:url("mouse.jpg")')
        flags[index] = 1
        mouseTimer.start(1.5*1000)

    # 老鼠显示时间结束槽函数
    # 功能： 随机选中地洞，显示下一个老鼠
    def mouseTimeout(self, holes, flags, missingEdit):
        # 检查每个地洞的状态
        for index in range(25):
            if flags[index] == 1:   # 当前洞中有未击中的老鼠，逃脱数加一，并还原成无老鼠状态
                self.missing += 1
                missingEdit.setText(str(self.missing))
                holes[index].setStyleSheet('border-image:url("hole.jpg")')
                flags[index] = 0
            if flags[index] == 0.5:    # 当前地洞处于被击中过的状态，只需还原成无老鼠状态
                holes[index].setStyleSheet('border-image:url("hole.jpg")')
                flags[index] = 0
        # 以系统时间为种子，随机选取一个地洞安排老鼠
        seed(time())
        index = randint(0, 24)
        holes[index].setStyleSheet('border-image:url("mouse.jpg")')
        flags[index] = 1
        # 计时器开始计时
        mouseTimer = self.sender()
        mouseTimer.start(1.5*1000)

    # 更新剩余时间槽函数
    # 功能： 每隔一秒更新游戏剩余时间
    def show_remainingTime(self, timer, remainingTimeEdit):
        remaintime = int(round(timer.remainingTime() / 1000, 0))
        remainingTimeEdit.setText(str(remaintime) + "秒")
        self.sender().start(1000)
        

if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = StackedWin()
    mainWindow.show()
    sys.exit(app.exec_())